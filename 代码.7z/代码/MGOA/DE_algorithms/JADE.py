import numpy as np
import matplotlib.pyplot as plt
from EA_toolbox import *


class JADE_global_original:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_find_PS,
        is_print,
        p,
        c,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = np.array(lb)
        self.ub = np.array(ub)
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.p = p
        self.c = c

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        # 初始化策略和参数
        self.mut = None
        self.crossp = None
        self.A = None
        self.u_CR = 0.5
        self.u_F = 0.5

        self.potential_solutions = []

    def adapt_parameters(self, Set_crossp, Set_F):
        def lehmer_mean(num):
            num = np.array(num)
            return np.sum(num**2) / np.sum(num)

        if len(Set_crossp) != 0:
            self.u_CR = (1 - self.c) * self.u_CR + self.c * np.average(Set_crossp)
        if len(Set_F) != 0:
            self.u_F = (1 - self.c) * self.u_F + self.c * lehmer_mean(Set_F)

    def initPopReplace(self, good_individuals):
        count = good_individuals.shape[0]
        all_index = np.arange(self.size)
        selected_index = np.random.choice(all_index, size=count, replace=False)
        self.X[selected_index] = good_individuals.copy()

    def optimize(self):
        for t in range(self.iter_num):
            # 存储成功的交叉率和突变率
            Set_crossp = []
            Set_F = []
            # 合并当代种群和被淘汰的父代个体
            mergeSet_A_P = self.merge_A_P()
            # 临时存储当代被淘汰的父代个体
            A_list = []
            # 重新计算突变率和交叉率
            self.calculate_F_CR()

            for individual_index in range(self.size):
                # 产生突变个体
                mutant = self.generate_mutant(mergeSet_A_P, individual_index)

                # 随机选一些维度，试验个体在这些维度上值为突变个体的值
                cross_points = np.random.rand(self.dim) < self.crossp[individual_index]
                # 如果没有选出任意一个维度，则随机指定一个
                if not np.any(cross_points):
                    cross_points[np.random.randint(0, self.dim)] = True
                # 产生试验个体，并计算适应度
                trial = np.where(cross_points, mutant, self.X[individual_index])
                score_trial = self.func(trial)
                # 比较，分别更新个体和全局的值和适应度
                if score_trial < self.X_score[individual_index]:
                    Set_crossp.append(self.crossp[individual_index])
                    Set_F.append(self.mut[individual_index])
                    A_list.append(self.X[individual_index].copy())
                    self.X_score[individual_index] = score_trial
                    self.X[individual_index] = trial
                    if score_trial < self.gbest_score:
                        self.gbest_score = score_trial

            self.operate_A(A_list)

            # 优化过程曲线
            self.gbest_scores.append(self.gbest_score)
            self.adapt_parameters(Set_crossp, Set_F)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            np.array(self.potential_solutions),
            None,
            self.gbest_scores,
        )

    def calculate_F_CR(self):
        def random_cauchy(u_F):
            return np.random.standard_cauchy(self.size) * 0.1 + u_F

        self.mut = np.clip(random_cauchy(self.u_F), 0, 1)
        self.crossp = np.clip(
            np.random.normal(loc=self.u_CR, scale=0.1, size=self.size), 0, 1
        )

    def merge_A_P(self):
        if self.A is not None:
            return np.concatenate((self.X, self.A), axis=0)
        else:
            return self.X.copy()

    def operate_A(self, A_list):
        if len(A_list) != 0:
            if self.A is None:
                self.A = np.array(A_list)
            else:
                self.A = np.concatenate((self.A, np.array(A_list)), axis=0)
        # 如果A超过容量限制，随机删除一些个体
        if self.A.shape[0] > self.size:
            remain_index = np.random.choice(self.A.shape[0], self.size, replace=False)
            self.A = self.A[remain_index]

    def generate_mutant(self, mergeSet_A_P, individual_index):
        # 选出p_best
        p_best_index = np.random.choice(
            np.argsort(self.X_score)[: int(self.size * self.p)]
        )
        p_best = self.X[p_best_index]
        # 选出x_r1和x_r2
        index_r1_list = [
            index for index in range(self.size) if index != individual_index
        ]
        r1_index = np.random.choice(index_r1_list)
        index_r2_list = [
            index
            for index in range(mergeSet_A_P.shape[0])
            if index != r1_index and index != individual_index
        ]
        r2_index = np.random.choice(index_r2_list)
        x_r1 = self.X[r1_index]
        x_r2 = mergeSet_A_P[r2_index]

        mutant = (
            self.X[individual_index]
            + self.mut[individual_index] * (p_best - self.X[individual_index])
            + self.mut[individual_index] * (x_r1 - x_r2)
        )
        mutant = np.clip(mutant, self.lb, self.ub)

        return mutant

    def plot_optimization(self):
        plt.semilogy(self.gbest_scores, "r-", linewidth=2)
        plt.xlabel("Iteration")
        plt.ylabel("Best Score")
        plt.title("SaDE Optimization Process")
        plt.show()
