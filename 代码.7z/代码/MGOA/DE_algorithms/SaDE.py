import numpy as np
import matplotlib.pyplot as plt
from EA_toolbox import *


class SaDE_global_original:

    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_find_PS,
        is_print,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = np.array(lb)
        self.ub = np.array(ub)
        self.is_find_PS = is_find_PS
        self.is_print = is_print

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        # 初始化策略和参数
        self.strategies = ["rand/1/bin", "rand/2/bin", "current-to-rand/1"]
        self.strategy_probs = np.ones(len(self.strategies)) / len(self.strategies)
        self.mut = np.random.normal(loc=0.5, scale=0.3)
        self.crossp = np.random.normal(loc=0.5, scale=0.1, size=self.size)

        self.potential_solutions = []

    def select_strategy(self):
        return np.random.choice(self.strategies, p=self.strategy_probs)

    def adapt_parameters(self, success_strategy_rates, success_crossp):
        self.strategy_probs = success_strategy_rates / np.sum(success_strategy_rates)
        self.mut = np.random.normal(loc=0.5, scale=0.3)
        if len(success_crossp) != 0:
            self.crossp = np.random.normal(
                loc=np.average(success_crossp), scale=0.01, size=self.size
            )

    def initPopReplace(self, good_individuals):
        count = good_individuals.shape[0]
        all_index = np.arange(self.size)
        selected_index = np.random.choice(all_index, size=count, replace=False)
        self.X[selected_index] = good_individuals.copy()

    def optimize(self):
        for t in range(self.iter_num):
            success_strategy_rates = np.ones(len(self.strategies))
            success_crossp = []
            for individual_index in range(self.size):
                # 依据概率选择一个突变策略
                strategy = self.select_strategy()
                # 产生突变个体
                mutant = self.generate_mutation(strategy, individual_index)
                mutant = np.clip(mutant, self.lb, self.ub)
                # 随机选一些维度，试验个体在这些维度上值为突变个体的值
                cross_points = np.random.rand(self.dim) < self.crossp[individual_index]
                # 如果没有选出任意一个维度，则随机指定一个
                if not np.any(cross_points):
                    cross_points[np.random.randint(0, self.dim)] = True
                # 产生试验个体，并计算适应度
                trial = np.where(cross_points, mutant, self.X[individual_index])
                score_trial = self.func(trial)
                # 比较，分别更新个体和全局的值和适应度
                if score_trial < self.X_score[individual_index]:
                    self.X_score[individual_index] = score_trial
                    self.X[individual_index] = trial
                    success_crossp.append(self.crossp[individual_index])
                    # 如果更优秀，则策略成功次数加一
                    success_strategy_rates[self.strategies.index(strategy)] += 1
                    if score_trial < self.gbest_score:
                        self.gbest_score = score_trial
            # 优化过程曲线
            self.gbest_scores.append(self.gbest_score)
            self.adapt_parameters(success_strategy_rates, success_crossp)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            np.array(self.potential_solutions),
            None,
            self.gbest_scores,
        )

    def generate_mutation(self, strategy, individual_index):
        idxs = [idx for idx in range(self.size) if idx != individual_index]

        if strategy == "rand/1/bin":
            a, b, c = self.X[np.random.choice(idxs, 3, replace=False)]
            mutant = np.clip(a + self.mut * (b - c), self.lb, self.ub)
        elif strategy == "rand/2/bin":
            a, b, c, d, e = self.X[np.random.choice(idxs, 5, replace=False)]
            mutant = np.clip(
                a + self.mut * (b - c) + self.mut * (d - e), self.lb, self.ub
            )
        elif strategy == "current-to-rand/1":
            a, b, c = self.X[np.random.choice(idxs, 3, replace=False)]
            mutant = np.clip(
                self.X[individual_index]
                + self.mut * (a - self.X[individual_index])
                + self.mut * (b - c),
                self.lb,
                self.ub,
            )

        return mutant

    def plot_optimization(self):
        plt.semilogy(self.gbest_scores, "r-", linewidth=2)
        plt.xlabel("Iteration")
        plt.ylabel("Best Score")
        plt.title("SaDE Optimization Process")
        plt.show()
