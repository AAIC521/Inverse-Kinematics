import numpy as np
import matplotlib.pyplot as plt
from EA_toolbox import *


class LSHADE_global_original:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_find_PS,
        is_print,
        H,
        A_count,
        p,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = np.array(lb)
        self.ub = np.array(ub)
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.H = H
        self.A_count = A_count
        self.p = p

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        # 初始化策略和参数
        self.mut = None
        self.crossp = None
        self.A = None
        self.M_CR = np.array([0.5 for _ in range(self.H)])
        self.M_F = np.array([0.5 for _ in range(self.H)])
        self.k = 0
        self.size_min = 4
        self.max_nfe = self.dim * 100000
        self.curr_nfe = 0
        self.init_size = self.size
        self.init_A_count = self.A_count

        self.potential_solutions = []

    def adapt_parameters(self, weight, Set_crossp, Set_F):
        def weight_lehmer_mean(num, weight):
            num = np.array(num)
            weight = np.array(weight)

            return np.sum(weight * num**2) / np.sum(weight * num)

        if len(weight) != 0:
            if np.max(Set_crossp) == 0:
                self.M_CR[self.k] = 0
            else:
                self.M_CR[self.k] = np.clip(
                    weight_lehmer_mean(Set_crossp, weight), 0, 1
                )
            self.M_F[self.k] = np.clip(weight_lehmer_mean(Set_F, weight), 0, 1)

            self.k += 1
            if self.k >= self.H:
                self.k = 0

    def initPopReplace(self, good_individuals):
        count = good_individuals.shape[0]
        all_index = np.arange(self.size)
        selected_index = np.random.choice(all_index, size=count, replace=False)
        self.X[selected_index] = good_individuals.copy()

    def optimize(self):
        for t in range(self.iter_num):
            # 存储成功的交叉率、突变率和权重
            Set_crossp = []
            Set_F = []
            weight = []
            # 合并当代种群和被淘汰的父代个体
            mergeSet_A_P = self.merge_A_P()
            # 临时存储当代被淘汰的父代个体
            A_list = []
            # 重新计算突变率和交叉率
            self.calculate_F_CR()

            for individual_index in range(self.size):
                self.curr_nfe += 1
                # 产生突变个体
                mutant = self.generate_mutant(mergeSet_A_P, individual_index)

                # 随机选一些维度，试验个体在这些维度上值为突变个体的值
                cross_points = np.random.rand(self.dim) < self.crossp[individual_index]
                # 如果没有选出任意一个维度，则随机指定一个
                if not np.any(cross_points):
                    cross_points[np.random.randint(0, self.dim)] = True
                # 产生试验个体，并计算适应度
                trial = np.where(cross_points, mutant, self.X[individual_index])
                score_trial = self.func(trial)
                # 比较，分别更新个体和全局的值和适应度
                if score_trial < self.X_score[individual_index]:
                    Set_crossp.append(self.crossp[individual_index])
                    Set_F.append(self.mut[individual_index])
                    A_list.append(self.X[individual_index].copy())
                    weight.append(np.abs(score_trial - self.X_score[individual_index]))
                    self.X_score[individual_index] = score_trial
                    self.X[individual_index] = trial
                    if score_trial < self.gbest_score:
                        self.gbest_score = score_trial

            self.operate_A(A_list)

            self.size_reduction()

            # 优化过程曲线
            self.gbest_scores.append(self.gbest_score)
            self.adapt_parameters(weight, Set_crossp, Set_F)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            np.array(self.potential_solutions),
            None,
            self.gbest_scores,
        )

    def size_reduction(self):
        # 调整种群
        curr_size = self.size
        self.size = int(
            self.init_size
            + self.curr_nfe / self.max_nfe * (self.size_min - self.init_size)
        )
        if curr_size > self.size:
            index_remain = np.argsort(self.X_score)[: self.size]
            self.X = self.X[index_remain]
            self.X_score = self.X_score[index_remain]

        # 调整A
        A_count = int(self.size / self.init_size * self.init_A_count)
        if self.A_count > A_count and A_count < self.A.shape[0]:
            self.A_count = A_count
            remain_index = np.random.choice(
                self.A.shape[0], self.A_count, replace=False
            )
            self.A = self.A[remain_index]

    def calculate_F_CR(self):
        def random_cauchy(u_F):
            return np.random.standard_cauchy(self.size) * 0.1 + u_F

        index_random = np.random.choice(self.H)
        selected_M_CR = self.M_CR[index_random]
        selected_M_F = self.M_F[index_random]
        if selected_M_CR == 0:
            self.mut = np.zeros(shape=self.size)
        else:
            self.mut = np.clip(random_cauchy(selected_M_CR), 0, 1)
        self.crossp = np.clip(
            np.random.normal(loc=selected_M_F, scale=0.1, size=self.size), 0, 1
        )

    def merge_A_P(self):
        if self.A is not None:
            return np.concatenate((self.X, self.A), axis=0)
        else:
            return self.X.copy()

    def operate_A(self, A_list):
        if len(A_list) != 0:
            if self.A is None:
                self.A = np.array(A_list)
            else:
                self.A = np.concatenate((self.A, np.array(A_list)), axis=0)
        # 如果A超过容量限制，随机删除一些个体
        if self.A.shape[0] > self.A_count:
            remain_index = np.random.choice(
                self.A.shape[0], self.A_count, replace=False
            )
            self.A = self.A[remain_index]

    def generate_mutant(self, mergeSet_A_P, individual_index):
        # 选出p_best
        p_best_index = np.random.choice(
            np.argsort(self.X_score)[: int(self.size * self.p)]
        )
        p_best = self.X[p_best_index]
        # 选出x_r1和x_r2
        index_r1_list = [
            index for index in range(self.size) if index != individual_index
        ]
        r1_index = np.random.choice(index_r1_list)
        index_r2_list = [
            index
            for index in range(mergeSet_A_P.shape[0])
            if index != r1_index and index != individual_index
        ]
        r2_index = np.random.choice(index_r2_list)
        x_r1 = self.X[r1_index]
        x_r2 = mergeSet_A_P[r2_index]

        mutant = (
            self.X[individual_index]
            + self.mut[individual_index] * (p_best - self.X[individual_index])
            + self.mut[individual_index] * (x_r1 - x_r2)
        )
        if np.any(mutant > self.ub):
            mutant = (self.ub + self.X[individual_index]) / 2
        elif np.any(mutant < self.lb):
            mutant = (self.lb + self.X[individual_index]) / 2

        return mutant

    def plot_optimization(self):
        plt.semilogy(self.gbest_scores, "r-", linewidth=2)
        plt.xlabel("Iteration")
        plt.ylabel("Best Score")
        plt.title("SaDE Optimization Process")
        plt.show()
