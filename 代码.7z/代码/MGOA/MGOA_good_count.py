import numpy as np
from MultiGen import MultiGenOA
from DE_algorithms import *
from QPSO_algorithms import *
from EA_toolbox import *
from Robot import *
import multiprocessing
import time

algorithm_name = {
    "QPSO_improved": QPSO_global_improved,
}
unified_parameters = {
    "populations": [2, 2],
    "gens": 2,
    "dim": 7,
    "sizes": [400, 400],
    "iter_num": 500,
    "lb": np.array(
        [-168.5, -143.5, -123.5, -290, -88, -229, -168.5],
        dtype=np.float32,
    ),
    "ub": np.array(
        [168.5, 43.5, 80, 290, 138, 229, 168.5],
        dtype=np.float32,
    ),
    "is_find_PS": False,
    "is_print": False,
}
unique_parameters = {
    "QPSO_improved": {"H": 20, "subPop_count": 4},
}


def get_MultiGenOA_parameters(cost_function, algorithm):
    algorithm_unique_parameters_name = [*unique_parameters[algorithm]]
    algorithm_unique_parameters_value = [
        unique_parameters[algorithm][parameters_name]
        for parameters_name in algorithm_unique_parameters_name
    ]
    OA_hyperparameters = [
        (
            cost_function,
            lattice_points_init,
            unified_parameters["dim"],
            unified_parameters["sizes"][0],
            unified_parameters["iter_num"],
            unified_parameters["lb"],
            unified_parameters["ub"],
            unified_parameters["is_find_PS"],
            unified_parameters["is_print"],
            *algorithm_unique_parameters_value,
        )
        for _ in range(unified_parameters["gens"])
    ]

    MultiGenOA_parameters = (
        cost_function,
        algorithm_name[algorithm],
        unified_parameters["gens"],
        unified_parameters["populations"],
        OA_hyperparameters,
        unified_parameters["sizes"],
        unified_parameters["lb"],
        unified_parameters["ub"],
        unified_parameters["is_print"],
    )
    return MultiGenOA_parameters


def all_test_data_one_poccessing(result_list_diff_poccessing, algorithm):
    result_in_one_poccessing = []
    for goal_index in range(test_data_global.shape[0]):
        goal = test_data_global[goal_index]

        def cost_function(angles):
            fact = get_orientation_and_position_batch(angles)
            return np.sum(np.square(fact - goal))

        MGOA = MultiGenOA(*get_MultiGenOA_parameters(cost_function, algorithm))
        best_fitness = MGOA.optimize()
        result_in_one_poccessing.append(best_fitness)

    result_in_one_poccessing = np.array(result_in_one_poccessing)

    result_list_diff_poccessing.append(result_in_one_poccessing)


num_test = 100

if __name__ == "__main__":
    start_time = time.time()
    print(
        "开始时间:",
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_time)),
    )

    algorithm_list = [*algorithm_name]

    data = []

    for i in algorithm_list:
        manager = multiprocessing.Manager()
        result_list_diff_poccessing = manager.list()  # 使用 Manager 的共享列表

        num_test_bench_list = split_into_chunks(num_test, chunk_size=20)

        sum_count_test = 0
        for num_test_bench in num_test_bench_list:
            print(f"算法:{i}\t轮次:{sum_count_test+1}/{num_test}")
            sum_count_test += num_test_bench

            processes = []
            for _ in range(num_test_bench):
                p = multiprocessing.Process(
                    target=all_test_data_one_poccessing,
                    args=(result_list_diff_poccessing, i),
                )
                processes.append(p)
                p.start()
            for p in processes:
                p.join()

            # 每运行一个批次就休息3分钟
            time.sleep(60 * 10)

        result_list_diff_poccessing = np.array(result_list_diff_poccessing)
        data.extend(result_list_diff_poccessing)

        # 每运行一个算法就休息10分钟
        # time.sleep(60 * 10)
    data = np.array(data)
    data_copy = [data[:, i] for i in range(data.shape[1])]

    print(
        "结束时间:",
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time())),
    )
    print(
        "总运行时间:",
        time.strftime("%H:%M:%S", time.gmtime(time.time() - start_time)),
    )

    plot_bar_chart(
        data_copy,
        1e-8,
        "Good Solutions Count for MGOA using ACQPSO",
        np.arange(len(data_copy)),
        "Good Solutions Count",
    )
