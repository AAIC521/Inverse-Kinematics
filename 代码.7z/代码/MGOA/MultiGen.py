import numpy as np
from sklearn.cluster import DBSCAN
import matplotlib.pyplot as plt
import time


class MultiGenOA:
    def __init__(
        self,
        fitness_function,
        optimization_algorithm,
        gens,
        populations,
        OA_hyperparameters,
        sizes,
        lb,
        ub,
        is_print,
    ):
        """
        1. fitness_function为适应度函数
        2. optimization_algorithm每个种群的优化算法
        3. gens为种群代数
        4. populations为每代种群的种群数
        5. OA_hyperparameters为每一代优化算法的超参数
        6. sizes为每一代种群中个体数
        """

        self.fitness_function = fitness_function
        self.global_optimization_algorithm = optimization_algorithm
        self.gens = gens
        self.populations = populations
        self.global_OA_hyperparameters = OA_hyperparameters
        self.sizes = sizes
        self.lb = lb
        self.ub = ub
        self.is_print = is_print

        self.best_position = None
        self.best_fitness = np.inf
        self.process_curve = []

        # 存储所有用于全局探索的种群的二维列表，第一维为代数，第二维为同一代的种群
        self.MultiGenPopulations = []
        for gen in range(self.gens):
            hyperparameters = self.global_OA_hyperparameters[gen]
            Populations = [
                self.global_optimization_algorithm(*hyperparameters)
                for _ in range(self.populations[gen])
            ]
            self.MultiGenPopulations.append(Populations)

        # 存储找到的所有有潜力的解
        self.PotentialSolutions = np.array([])
        # 所有有潜力的解的适应度
        self.PotentialSolutions_fitness = np.array([])
        # 存储细致优化后没有找到优质解的区域
        self.areas_no_good_solutions = []

    def optimize(self):
        """主优化过程"""
        for gen in range(self.gens):
            # 当代所有种群的优化过程曲线
            process_curve_gen = []
            # 选潜在解
            selected_solutions, selected_count, selected_count_pop = (
                self.select_PotentialSolutions_to_nextPops(gen)
            )
            # 清空潜在解
            self.PotentialSolutions = np.array([])
            self.PotentialSolutions_fitness = np.array([])
            # 对每一个种群进行操作
            for i in range(self.populations[gen]):
                # 全局探索
                # 选中种群
                pop = self.MultiGenPopulations[gen][i]
                # 将潜力解放入种群中
                self.put_potential_solutions_into_pop(
                    pop, selected_solutions, selected_count, selected_count_pop, i
                )
                # 种群迭代，得到该种群最优解、潜在解、优化过程曲线
                (
                    best_position,
                    best_fitness,
                    potential_solutions,
                    potential_solutions_fitness,
                    process_curve,
                ) = pop.optimize()

                # 存储邻域，即收敛的区域
                self.storage_neighborhoods(best_position)
                # 存储找到的所有有潜力的解
                self.storage_potential_solutions(
                    potential_solutions, potential_solutions_fitness
                )

                # 更新最优解
                self.update_best(best_position, best_fitness)
                # 存储每个种群的进化曲线
                process_curve_gen.append(process_curve)

            # 存储当代所有种群优化过程曲线
            self.process_curve.append(process_curve_gen)
        if self.is_print:
            # 输出最优适应度，程序结束
            print(self.best_fitness)
        return self.best_fitness

    # 将潜力解放入种群中的函数
    def put_potential_solutions_into_pop(
        self, pop, selected_solutions, selected_count, selected_count_pop, i
    ):
        if selected_count is not None:
            pop.initPopReplace(
                selected_solutions[
                    selected_count_pop * i : selected_count_pop * (i + 1)
                ].copy()
            )

    # 存储邻域的函数
    def storage_neighborhoods(self, best_position):
        # 以元组形式存到列表中
        self.areas_no_good_solutions.append(
            (best_position.copy(), (self.ub - self.lb) / 200)
        )

    # 存储潜在解的函数
    def storage_potential_solutions(
        self, potential_solutions, potential_solutions_fitness
    ):
        # 如果原来的集合中本就没有数据，则直接复制
        if self.PotentialSolutions.shape[0] == 0:
            self.PotentialSolutions = potential_solutions.copy()
            if potential_solutions_fitness is not None:
                self.PotentialSolutions_fitness = potential_solutions_fitness.copy()
        # 如果集合中有其他种群的潜在解，则合并
        else:
            self.PotentialSolutions = np.concatenate(
                (self.PotentialSolutions, potential_solutions), axis=0
            )
            if potential_solutions_fitness is not None:
                self.PotentialSolutions_fitness = np.concatenate(
                    (self.PotentialSolutions_fitness, potential_solutions_fitness),
                    axis=0,
                )

    # 更新最优解位置和适应度的函数
    def update_best(self, best_position, best_fitness):
        if best_fitness < self.best_fitness:
            self.best_fitness = best_fitness
            self.best_position = best_position

    # 对潜在解的操作，包括去重、聚类、删除邻域内的点
    def processing_PotentialSolutions(self):
        # 存储不在任何邻域内的点的索引
        index_not_in_any_neighbor = []
        # 遍历所有邻域
        for i in range(len(self.areas_no_good_solutions)):
            # 计算所有潜在解与邻域中心的欧式距离
            distance_list = np.abs(
                self.PotentialSolutions - self.areas_no_good_solutions[i][0]
            )
            # 挑选出所有不在邻域内的点的索引，并存入列表中
            index_not_in_one_neighbor = np.arange(self.PotentialSolutions.shape[0])[
                np.any(distance_list > self.areas_no_good_solutions[i][1])
            ]
            index_not_in_any_neighbor.extend(index_not_in_one_neighbor)
        # 对列表中的索引去重
        index_not_in_any_neighbor = np.unique(index_not_in_any_neighbor)
        # 将损失值不低于0.01的潜在解挑出来
        index_not_in_any_neighbor_and_out_fitness = index_not_in_any_neighbor[
            np.where(self.PotentialSolutions_fitness[index_not_in_any_neighbor] > 0.1)[
                0
            ]
        ]
        self.PotentialSolutions = self.PotentialSolutions[
            index_not_in_any_neighbor_and_out_fitness
        ]
        self.PotentialSolutions_fitness = self.PotentialSolutions_fitness[
            index_not_in_any_neighbor_and_out_fitness
        ]

    # 从潜在解集合中选择一些放入下一代种群
    def select_PotentialSolutions_to_nextPops(self, gen):
        # 潜在解集合的数量
        count_potentia_solutions = self.PotentialSolutions.shape[0]
        # 如果潜在解集合是空的，那么直接返回None
        if not (count_potentia_solutions != 0):
            return None, None, None

        # 当前代次的种群数量
        count_pops = self.populations[gen]
        # 每个种群能获得的最大潜在解数量，为种群个体数的0.2
        max_count_pop = int(self.sizes[gen] * 0.2)
        # 计算放入下一代种群的最大个体数
        selected_count_max = count_pops * max_count_pop
        # 假设所需最大个体数超过集合总数，则将集合中个体均分给下代种群
        selected_count_pop = count_potentia_solutions // count_pops

        # 对潜在解集合进行处理
        self.processing_PotentialSolutions()

        # 如果最大个体数小于潜在解集合总量，则下代每个个体均能得到规定的最大数量的潜在解
        if selected_count_max < count_potentia_solutions:
            # 每个种群获得的潜在解数量为最大数量
            selected_count_pop = max_count_pop
            # 计算最大精英数量，最大数量的10倍
            elite_count_max = selected_count_max * 20
            # 如果最大精英数量大于潜在解集合总量，则整个集合都作为精英
            if elite_count_max > count_potentia_solutions:
                elite_count_max = count_potentia_solutions

            # 选出精英
            best_index = np.argsort(self.PotentialSolutions_fitness)[:elite_count_max]
            # 提取精英的适应度
            best_fitness = self.PotentialSolutions_fitness[best_index]
            # 适应度越差，被选中概率越高
            chosen_prob = best_fitness / np.sum(best_fitness)
            chosen_index = np.random.choice(
                best_index, selected_count_max, replace=False, p=chosen_prob
            )
            self.PotentialSolutions = self.PotentialSolutions[chosen_index].copy()

        # 打乱潜在解集合的顺序
        np.random.shuffle(self.PotentialSolutions)
        # 被选中放入下一代的潜在解
        selected_solutions = self.PotentialSolutions.copy()

        # 计算所有种群获得的潜在解总量
        selected_count = selected_count_pop * count_pops

        return selected_solutions, selected_count, selected_count_pop

    # 绘制每一个种群优化过程图像
    def plot_optimization(self):
        for gen in range(len(self.process_curve)):
            for pop in range(len(self.process_curve[gen])):
                # 绘制优化过程
                plt.figure(figsize=(10, 6))
                plt.plot(self.process_curve[gen][pop], label="MGOA", color="red")
                plt.xlabel("Iteration")
                plt.ylabel("Fitness")
                plt.yscale("log")
                plt.title(f"gen {gen} pop {pop} Optimization Process")
                plt.legend()
                plt.grid(True)
                plt.show()
