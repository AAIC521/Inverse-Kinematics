import numpy as np


# 初始化机器人的Denavit-Hartenberg（DH）参数表
def init_dh_table():
    # 每一行代表一个关节，包含[d, theta, a, alpha]参数
    DH_table = np.array(
        [
            [0.166, 0, -0.030, -90],
            [0, 0, 0.030, 90],
            [0.2515, 0, 0.0405, -90],
            [0, 0, 0.0405, -90],
            [0.265, 0, 0.027, -90],
            [0, 0, -0.027, 90],
            [0.036, 0, 0, 0],
        ],
        dtype=np.float32,
    )
    return DH_table


# 根据给定的关节角度计算总变换矩阵
def calculate_transforms(DH_table, angles):
    # 将所有关节角度从度转换为弧度
    thetas = np.deg2rad(angles)
    # 预先计算thetas和alphas的余弦和正弦值
    cos_thetas = np.cos(thetas)
    sin_thetas = np.sin(thetas)
    alphas = np.deg2rad(DH_table[:, 3])
    cos_alphas = np.cos(alphas)
    sin_alphas = np.sin(alphas)

    # 初始化一个列表来存储所有的 T 矩阵
    T_matrices = []

    # 创建所有的 T 矩阵
    for i in range(DH_table.shape[0]):
        # 创建第 i 个变换矩阵 T
        T = np.array(
            [
                [
                    cos_thetas[i],
                    -sin_thetas[i] * cos_alphas[i],
                    sin_thetas[i] * sin_alphas[i],
                    DH_table[i, 2] * cos_thetas[i],
                ],
                [
                    sin_thetas[i],
                    cos_thetas[i] * cos_alphas[i],
                    -cos_thetas[i] * sin_alphas[i],
                    DH_table[i, 2] * sin_thetas[i],
                ],
                [
                    0,
                    sin_alphas[i],
                    cos_alphas[i],
                    DH_table[i, 0],
                ],
                [0, 0, 0, 1],
            ]
        )

        # 将 T 添加到列表中
        T_matrices.append(T)

    # 顺序乘以所有变换矩阵以获得总变换矩阵
    total_transform = np.eye(4)
    for T in T_matrices:
        total_transform = np.dot(total_transform, T)

    return total_transform


def get_orientation_and_position_batch(angles_batch):
    DH_table = init_dh_table()
    # 初始化一个列表来存储每个样本的方向和位置
    orientations_positions = []
    # 对批量数据中的每个样本进行循环处理
    total_transform = calculate_transforms(DH_table, angles_batch)

    orientation = total_transform[:3, :3].reshape(-1)

    position = total_transform[:3, 3].reshape(-1)

    orientations_positions.append(np.concatenate((orientation, position), 0))

    # 将列表转换为张量
    orientations_positions = np.stack(orientations_positions)

    return orientations_positions


def generate_random_angles(batch=1):
    lower_limit = np.array(
        [-168.5, -143.5, -123.5, -290, -88, -229, -168.5],
        dtype=np.float32,
    )

    upper_limit = np.array(
        [168.5, 43.5, 80, 290, 138, 229, 168.5],
        dtype=np.float32,
    )

    return np.random.rand(batch, 7) * (upper_limit - lower_limit) + lower_limit


# random_angles = generate_random_angles()
# print(get_orientation_and_position_batch(random_angles))
