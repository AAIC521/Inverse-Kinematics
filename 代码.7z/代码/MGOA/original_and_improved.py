import numpy as np
from MultiGen import MultiGenOA
from DE_algorithms import *
from QPSO_algorithms import *
from EA_toolbox import *
from Robot import *
import multiprocessing
import time

algorithm_name = {
    "QPSO_original": QPSO_global_original,
    "QPSO_improved": QPSO_global_improved,
}
unified_parameters = {
    "dim": 7,
    "sizes": 400,
    "iter_num": 500,
    "lb": np.array(
        [-168.5, -143.5, -123.5, -290, -88, -229, -168.5],
        dtype=np.float32,
    ),
    "ub": np.array(
        [168.5, 43.5, 80, 290, 138, 229, 168.5],
        dtype=np.float32,
    ),
    "is_find_PS": False,
    "is_print": False,
}
unique_parameters = {
    "QPSO_original": {"a": 0.45},
    "QPSO_improved": {"H": 20, "subPop_count": 4},
}


def get_MultiGenOA_parameters(cost_function, algorithm):
    algorithm_unique_parameters_name = [*unique_parameters[algorithm]]
    algorithm_unique_parameters_value = [
        unique_parameters[algorithm][parameters_name]
        for parameters_name in algorithm_unique_parameters_name
    ]
    if algorithm == "QPSO_improved":
        size = unified_parameters["sizes"]
        iter_num = unified_parameters["iter_num"]
    else:
        size = int(unified_parameters["sizes"] * 3 / 4)
        iter_num = unified_parameters["iter_num"] * 2
    OA_hyperparameters = (
        cost_function,
        lattice_points_init,
        unified_parameters["dim"],
        size,
        iter_num,
        unified_parameters["lb"],
        unified_parameters["ub"],
        unified_parameters["is_find_PS"],
        unified_parameters["is_print"],
        *algorithm_unique_parameters_value,
    )

    return OA_hyperparameters


def all_test_data_one_poccessing(result_list_diff_poccessing, algorithm):
    result_in_one_poccessing = []
    for goal_index in range(test_data_global.shape[0]):
        goal = test_data_global[goal_index]  

        def cost_function(angles):
            fact = get_orientation_and_position_batch(angles)
            return np.sum(np.square(fact - goal))

        pop = algorithm_name[algorithm](
            *get_MultiGenOA_parameters(cost_function, algorithm)
        )
        _, best_fitness, _, _ = pop.optimize()
        result_in_one_poccessing.append(best_fitness)

    result_in_one_poccessing = np.array(result_in_one_poccessing)

    result_list_diff_poccessing.append(result_in_one_poccessing)


num_test = 100

if __name__ == "__main__":
    start_time = time.time()
    print(
        "开始时间:",
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_time)),
    )

    algorithm_list = [*algorithm_name]

    middle = []
    worst = []
    std = []

    middle_middle = []
    middle_worst = []
    worst_worst = []
    worst_middle = []
    std_worst = []
    std_middle = []

    original_and_improved_whole_result = []
    original_and_improved_whole_result_log = []

    for i in algorithm_list:
        manager = multiprocessing.Manager()
        result_list_diff_poccessing = manager.list()  # 使用 Manager 的共享列表

        num_test_bench_list = split_into_chunks(num_test, chunk_size=20)

        sum_count_test = 0
        for num_test_bench in num_test_bench_list:
            print(f"算法:{i}\t轮次:{sum_count_test+1}/{num_test}")
            sum_count_test += num_test_bench

            processes = []
            for _ in range(num_test_bench):
                p = multiprocessing.Process(
                    target=all_test_data_one_poccessing,
                    args=(result_list_diff_poccessing, i),
                )
                processes.append(p)
                p.start()
            for p in processes:
                p.join()

            # 每运行一个批次就休息3分钟
            time.sleep(60 * 3)

        result_list_diff_poccessing = np.array(result_list_diff_poccessing)
        median_each_test_data = np.median(result_list_diff_poccessing, axis=0)
        worst_each_test_data = np.max(result_list_diff_poccessing, axis=0)
        std_each_test_data = np.std(result_list_diff_poccessing, axis=0)

        middle.append(median_each_test_data)
        worst.append(worst_each_test_data)
        std.append(std_each_test_data)

        middle_middle.append(np.median(median_each_test_data))
        middle_worst.append(np.max(median_each_test_data))
        worst_middle.append(np.median(worst_each_test_data))
        worst_worst.append(np.max(worst_each_test_data))
        std_middle.append(np.median(std_each_test_data))
        std_worst.append(np.max(std_each_test_data))

        original_and_improved_whole_result.append(result_list_diff_poccessing.copy())

        # 每运行一个算法就休息10分钟
        time.sleep(60 * 10)

    original_and_improved_whole_result_log = np.log10(
        original_and_improved_whole_result
    )

    print(
        "结束时间:",
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time())),
    )
    print(
        "总运行时间:",
        time.strftime("%H:%M:%S", time.gmtime(time.time() - start_time)),
    )

    for i, algorithmName in enumerate(algorithm_list):
        print("\n")
        print(f"算法：{algorithmName}")
        print(f"最差的最差：{worst_worst[i]}")
        print(f"最差的中位数：{worst_middle[i]}")
        print(f"中位数的最差：{middle_worst[i]}")
        print(f"中位数的中位数：{middle_middle[i]}")
        print(f"标准差的最差：{std_worst[i]}")
        print(f"标准差的中位数：{std_middle[i]}")

    plot_comparison_boxplot(
        original_and_improved_whole_result_log[0],
        original_and_improved_whole_result_log[1],
        "Original VS Improved",
        is_log=True,
    )
