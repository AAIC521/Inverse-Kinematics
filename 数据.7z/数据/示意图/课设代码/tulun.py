import numpy as np
from numpy import pi
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
from matplotlib.backends.backend_pgf import PdfPages


# 定义子函数
def fun_1(x):
    a = -5184 / (25 * (pi**3))
    b = 1224 / (5 * (pi**2))
    return a * (x**3) + b * (x**2)


def fun_1_d(x):
    a = -5184 / (25 * (pi**3))
    b = 1224 / (5 * (pi**2))
    return 3 * a * (x**2) + 2 * b * x


def fun_2(x):
    return 80 / pi * x - 40 / 9


def fun_2_d(x):
    return 80 / pi


def fun_3(x):
    a = -67392 / (25 * (pi**3))
    b = 237888 / (25 * (pi**2))
    c = -274944 / (25 * pi)
    d = 106424 / 25
    return a * (x**3) + b * (x**2) + c * x + d


def fun_3_d(x):
    a = -67392 / (25 * (pi**3))
    b = 237888 / (25 * (pi**2))
    c = -274944 / (25 * pi)
    return 3 * a * (x**2) + 2 * b * x + c


def fun_4(x):
    a = 810 / (pi**3)
    b = -4050 / (pi**2)
    c = 6480 / pi
    d = -3240
    return a * (x**3) + b * (x**2) + c * x + d


def fun_4_d(x):
    a = 810 / (pi**3)
    b = -4050 / (pi**2)
    c = 6480 / pi
    return 3 * a * (x**2) + 2 * b * x + c


# 定义主函数
def fun(x):
    if 0 <= x <= 5 * pi / 9:
        return fun_1(x)
    elif 5 * pi / 9 < x <= 19 * pi / 18:
        return fun_2(x)
    elif 19 * pi / 18 < x <= 4 * pi / 3:
        return fun_3(x)
    elif 4 * pi / 3 < x <= 2 * pi:
        return fun_4(x)


def fun_d(x):
    if 0 <= x <= 5 * pi / 9:
        return fun_1_d(x)
    elif 5 * pi / 9 < x <= 19 * pi / 18:
        return fun_2_d(x)
    elif 19 * pi / 18 < x <= 4 * pi / 3:
        return fun_3_d(x)
    elif 4 * pi / 3 < x <= 2 * pi:
        return fun_4_d(x)


# 极坐标方程
def polar_fun(theta):
    r = fun(theta) + R
    return r, theta


def polar_fun_d(theta):
    a = fun_d(theta) * np.sin(theta) + (fun(theta) + R) * np.cos(theta)
    b = fun_d(theta) * np.cos(theta) - (fun(theta) + R) * np.sin(theta)
    return a / b


def polar_fun_k(theta):
    return -1 / polar_fun_d(theta)


# Initialize global variables
prev_X, prev_Y = None, None


def Fun(theta, l, direction):
    global prev_X, prev_Y

    # Calculate k based on polar_fun_k(theta)
    k = polar_fun_k(theta)
    cos = np.abs(1 / np.sqrt(1 + k**2))
    sin = np.abs(k * cos)

    # Adjust signs of cos and sin based on direction
    if direction == "up":
        if k < 0:
            cos = -cos
    elif direction == "down":
        sin = -sin
        if k > 0:
            cos = -cos

    # Calculate X and Y
    X = polar_fun(theta)[0] * np.cos(theta) + l * cos
    Y = polar_fun(theta)[0] * np.sin(theta) + l * sin

    # Threshold check
    therd = 1
    if prev_X is not None and prev_Y is not None:
        if np.abs(X - prev_X) > therd or np.abs(Y - prev_Y) > therd:
            cos = -cos
            sin = -sin
            X = polar_fun(theta)[0] * np.cos(theta) + l * cos
            Y = polar_fun(theta)[0] * np.sin(theta) + l * sin

    # Update prev_X and prev_Y
    prev_X, prev_Y = X, Y

    return X, Y


# 生成数据点
l_1 = 0
R = 50
l_2 = 40
theta_1 = np.linspace(0.00001, pi - 0.00001, 1000)
theta_2 = np.linspace(pi + 0.00001, pi * 2 - 0.00001, 1000)

X_1, Y_1 = zip(*[Fun(x, l_1, "down") for x in theta_1])
X_2, Y_2 = zip(*[Fun(x, l_1, "down") for x in theta_2])

X = X_1 + X_2
Y = Y_1 + Y_2
# 绘制第一条曲线
plt.plot(X, Y, label="Contour lines 1", linestyle="--")


# # 绘制第二条曲线
X_1, Y_1 = zip(*[Fun(x, l_2, "up") for x in theta_1])
X_2, Y_2 = zip(*[Fun(x, l_2, "up") for x in theta_2])

X = X_1 + X_2
Y = Y_1 + Y_2

plt.plot(X, Y, label="Contour lines 2", linestyle="--")

plt.scatter(0, 0, marker="*", color="red", s=80, label="Global best")
plt.scatter(-100, -100, marker="o", color="black", s=70, label="Personal best")

num_points = 500
P = np.array([-100, -100])
G = np.array([0, 0])

a = 0.5
random_factor = np.random.normal(loc=a**0.5, scale=0.1, size=(num_points, 2))

# random_factor = np.random.rand(num_points, 2)

points = (1 - random_factor) * P + random_factor * G
x = points[:, 0]
y = points[:, 1]
xy = np.vstack([x, y])
z = gaussian_kde(xy)(xy)
plt.scatter(
    x, y, c=z, cmap="viridis", alpha=0.15, edgecolors="w", label="Random Points"
)

# 添加图例
plt.legend(loc="lower right")

# 设置单位长度相等
plt.axis("equal")
plt.xticks([])
plt.yticks([])
filename = "lalal" + ".png"
# plt.savefig(filename, dpi=300, bbox_inches="tight")

# 保存为 SVG 矢量图
plt.savefig("plot1.svg", format="svg", dpi=500, bbox_inches="tight")

# 显示图像
plt.show()
