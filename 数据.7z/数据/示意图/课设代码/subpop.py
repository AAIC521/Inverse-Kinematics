import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import PowerNorm
from scipy.stats import gaussian_kde


# 定义Ackley函数
def ackley(x, y):
    return (
        -20 * np.exp(-0.2 * np.sqrt(0.5 * (x**2 + y**2)))
        - np.exp(0.5 * (np.cos(2 * np.pi * x) + np.cos(2 * np.pi * y)))
        + np.e
        + 20
    )


# 创建网格点
x = np.linspace(-2, 2, 500)
y = np.linspace(-2, 2, 500)
X, Y = np.meshgrid(x, y)
Z = ackley(X, Y)

# 使用 PowerNorm 绘制二维平面图
plt.contourf(X, Y, Z, levels=500, cmap="Greys", norm=PowerNorm(gamma=0.5))
plt.colorbar(label="Function value")

points = np.random.uniform(low=-2, high=2, size=(500, 2))

points1 = np.random.normal(loc=0, scale=0.05, size=(25, 2))
points2 = np.random.normal(loc=1, scale=0.05, size=(25, 2))
points3 = np.random.normal(loc=-1, scale=0.05, size=(25, 2))
points = np.concatenate((points1, points2, points3), axis=0)

x = points[:, 0]
y = points[:, 1]
best_index = np.argmin(x**2 + y**2)
G = points[best_index]
count_points = points.shape[0]
random_factor = np.random.rand(count_points, 2)
new_points = np.array(
    [
        G * random_factor[i] + points[i] * (1 - random_factor[i])
        for i in range(count_points)
    ]
)
points = np.concatenate((points, new_points), axis=0)

count_points = points.shape[0]
points = np.random.normal(loc=0, scale=0.05, size=(count_points, 2))

points = np.clip(points, -2, 2)
np.random.shuffle(points)
x = points[:, 0]
y = points[:, 1]
xy = np.vstack([x, y])
z = gaussian_kde(xy)(xy)


plt.scatter(
    x, y, c=z, cmap="viridis", alpha=0.25, edgecolors="w", label="Random Points"
)

# 添加标签
plt.xticks([])
plt.yticks([])

# 保存为 SVG 矢量图
plt.savefig("plot5.png", format="png", dpi=300, bbox_inches="tight")

# 显示图像
plt.show()
